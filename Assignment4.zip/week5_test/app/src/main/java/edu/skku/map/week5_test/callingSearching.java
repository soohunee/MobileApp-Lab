package edu.skku.map.week5_test;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class callingSearching extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calling_searching);

        Button search = findViewById(R.id.searchbutton);
        Button call = findViewById(R.id.calling);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText keyword = findViewById(R.id.searchkeyword);
                String word = keyword.getText().toString();
                Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                intent.putExtra(SearchManager.QUERY, word);
                startActivity(intent);
            }
        });
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText phonenumber = findViewById(R.id.phonenumber);
                Uri number = Uri.parse("tel:" + phonenumber.getText().toString());
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(number);
                startActivity(intent);
            }
        });

    }
}