package edu.skku.map.week5_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText id = findViewById(R.id.idtext);
        EditText pass = findViewById(R.id.pwdtext);
        String correctid = "MAP";
        String correctpwd = "weloveprofessor";
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, callingSearching.class);
                if (id.getText().toString().equals(correctid) && pass.getText().toString().equals(correctpwd)){
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }


}