package com.example.week11assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
