import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class Page1 extends StatelessWidget {
  final Map<String, String> arguments;

  Page1(this.arguments);

  @override
  Widget build(BuildContext context) {
    Page1CounterProvider counter_1 = Provider.of<Page1CounterProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Page1"),
      ),
      body: Center(
        child:Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(arguments["user-msg1"]),
            Text(arguments["user-msg2"]),
            Consumer<Page1CounterProvider>(
              builder: (context, counter_1, child) => Text(
                'Page1 Count : ${counter_1.counter}',
                style : Theme.of(context).textTheme.headline5,
              ),
            )
          ],
        )
      ),
        floatingActionButton:FloatingActionButton(
          onPressed: () => counter_1.incrementCounter(),
          tooltip: 'increment',
          child : Icon(Icons.add),
        )
    );
  }
}

class Page1CounterProvider with ChangeNotifier{
  int _counter;
  get counter => _counter;
  Page1CounterProvider(this._counter);
  void incrementCounter(){
    _counter ++;
    notifyListeners();
  }
}