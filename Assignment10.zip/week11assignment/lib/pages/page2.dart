import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class Page2 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    Page2CounterProvider counter_2 = Provider.of<Page2CounterProvider>(context);

    return Scaffold(
        appBar: AppBar(
          title: Text("Page2"),
        ),
        body: Center(
            child:Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Hi! Welcome to Page 2"),
                Consumer<Page2CounterProvider>(
                  builder: (context, counter_2, child) => Text(
                    'Page2 Count : ${counter_2.counter}',
                    style : Theme.of(context).textTheme.headline5,
                  ),
                )
              ],
            )
        ),
        floatingActionButton:FloatingActionButton(
          onPressed: () => counter_2.incrementCounter(),
          tooltip: 'increment',
          child : Icon(Icons.add),
        )
    );
  }
}

class Page2CounterProvider with ChangeNotifier{
  int _counter;
  get counter => _counter;
  Page2CounterProvider(this._counter);
  void incrementCounter(){
    _counter ++;
    notifyListeners();
  }
}