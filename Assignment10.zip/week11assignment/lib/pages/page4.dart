import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class Page4 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    Page4CounterProvider counter_4 = Provider.of<Page4CounterProvider>(context);

    return Scaffold(
        appBar: AppBar(
          title: Text("Page4"),
        ),
        body: Center(
            child:Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Hi! Welcome to Page 4"),
                Consumer<Page4CounterProvider>(
                  builder: (context, counter_4, child) => Text(
                    'Page4 Count : ${counter_4.counter}',
                    style : Theme.of(context).textTheme.headline5,
                  ),
                )
              ],
            )
        ),
        floatingActionButton:FloatingActionButton(
          onPressed: () => counter_4.incrementCounter(),
          tooltip: 'increment',
          child : Icon(Icons.add),
        )
    );
  }
}

class Page4CounterProvider with ChangeNotifier{
  int _counter;
  get counter => _counter;
  Page4CounterProvider(this._counter);
  void incrementCounter(){
    _counter ++;
    notifyListeners();
  }
}