import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week11assignment/pages/page1.dart';
import 'package:week11assignment/pages/page2.dart';
import 'package:week11assignment/pages/page3.dart';
import 'package:week11assignment/pages/page4.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider(create:(context) => Page1CounterProvider(0)),
          ChangeNotifierProvider(create:(context) => Page2CounterProvider(0)),
          ChangeNotifierProvider(create:(context) => Page3CounterProvider(0)),
          ChangeNotifierProvider(create:(context) => Page4CounterProvider(0)),
        ],
     child : MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      onGenerateRoute: (routerSettings){
        switch(routerSettings.name){
          case '/':
            return MaterialPageRoute(builder: (_) => MyHomePage(title : "Dynamic Routing"));
          case '/page1':
            return MaterialPageRoute(builder: (_) => Page1(routerSettings.arguments));
          case '/page2':
            return MaterialPageRoute(builder: (_) => Page2());
          case '/page3':
            return MaterialPageRoute(builder: (_) => Page3());
          case '/page4':
            return MaterialPageRoute(builder: (_) => Page4());
          default:
            return MaterialPageRoute(builder: (_) => MyHomePage(title : "Error Unknown Route !"));

        }
      }
     )
    );
  }
}
class MyHomePage extends StatelessWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".
  final String title;
  @override
  Widget build(BuildContext context) {
    final Page1CounterProvider counter_1 = Provider.of<Page1CounterProvider>(context);
    final Page2CounterProvider counter_2 = Provider.of<Page2CounterProvider>(context);
    final Page3CounterProvider counter_3 = Provider.of<Page3CounterProvider>(context);
    final Page4CounterProvider counter_4 = Provider.of<Page4CounterProvider>(context);
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          ElevatedButton(
            child:Text("Move to Page1"),
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/page1',
                arguments: {"user-msg1": "Move to Page1 by Dynamic Navigation",
                  "user-msg2": "Welcome to Page1",
                },
              );
            },
          ),
          ElevatedButton(
            child:Text("Move to Page2"),
            onPressed: (){
              Navigator.pushNamed(context,'/page2');
            },
          ),
          ElevatedButton(
            child:Text("Move to Page3"),
            onPressed: (){
              Navigator.pushNamed(context,'/page3');
            },
          ),
          ElevatedButton(
            child:Text("Move to Page4"),
            onPressed: (){
              Navigator.pushNamed(context,'/page4');
            },
          ),
          ElevatedButton(
            child:Text("Unknown"),
            onPressed: (){
              Navigator.pushNamed(context,'default');
            },
          ),
          Consumer<Page1CounterProvider>(
            builder: (context, counter_1, child) => Text(
              'Page1 Count : ${counter_1.counter}',
              style : Theme.of(context).textTheme.headline5,
            ),
          ),
          Consumer<Page2CounterProvider>(
            builder: (context, counter_2, child) => Text(
              'Page2 Count : ${counter_2.counter}',
              style : Theme.of(context).textTheme.headline5,
            ),
          ),
          Consumer<Page3CounterProvider>(
            builder: (context, counter_3, child) => Text(
              'Page3 Count : ${counter_3.counter}',
              style : Theme.of(context).textTheme.headline5,
            ),
          ),
          Consumer<Page4CounterProvider>(
            builder: (context, counter_4, child) => Text(
              'Page4 Count : ${counter_4.counter}',
              style : Theme.of(context).textTheme.headline5,
            ),
          )
        ],
        )
      ),
    );
  }
}
