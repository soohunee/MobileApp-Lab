package com.example.week8labassignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
