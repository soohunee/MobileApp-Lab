package edu.skku.map.week4_exercise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

import edu.skku.map.week4_exercise.R;

public class MainActivity extends AppCompatActivity {
    ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mListView = findViewById(R.id.listView);
        Button fbutton = (Button)findViewById(R.id.first);
        Button sbutton = (Button)findViewById(R.id.second);
        Button tbutton = (Button)findViewById(R.id.third);
        TextView textView = (TextView)findViewById(R.id.name);

        ArrayList<String> data = new ArrayList<>();
        ArrayList<String> fdata = new ArrayList<>();
        ArrayList<String> sdata = new ArrayList<String>();
        ArrayList<String> tdata = new ArrayList<String>();
        for (int i=0;i<10;i++){
            String fele = Integer.toString(i+1);
            String sele = Integer.toString(1<<i+1);
            fdata.add(fele);
            sdata.add(sele);
        }

        tdata.add("2016314364");
        tdata.add("ParkSoohun");
        tdata.add("Department of Software");
        tdata.add("College of Software");
        tdata.add("Sungkyunkwan University");
        ArrayAdapter<String> fadapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, fdata);
        ArrayAdapter<String> sadapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sdata);
        ArrayAdapter<String> tadapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tdata);

        fbutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mListView.setAdapter (fadapter);
                textView.setText("FIRST");
            }
        });
        sbutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mListView.setAdapter (sadapter);
                textView.setText("SECOND");
            }
        });
        tbutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mListView.setAdapter (tadapter);
                textView.setText("THIRD");
            }
        });



    }
}