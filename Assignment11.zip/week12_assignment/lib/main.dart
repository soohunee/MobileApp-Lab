import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


Future<Album> fetchAlbum() async{
  final response=
      await http.get(Uri.http('swopenAPI.seoul.go.kr','/api/subway/4c4f6b764d736f6f36345657616865/json/realtimeStationArrival/0/5/성균관대'));

  if (response.statusCode == 200) {
    return Album.fromJson(jsonDecode(response.body));
  } else{
    throw Exception('Failed to load album');
  }
}

class Album{
  final List realtimeArvl;
  final int rowNum;
  final int subwayId;
  final int trainLineNm;
  final String subwayHeading;
  final String arvlMsg2;

  Album({@required this.realtimeArvl,@required this.rowNum, @required this.subwayId, @required this.trainLineNm,
    @required this.subwayHeading,@required this.arvlMsg2});

  factory Album.fromJson(Map<String, dynamic> json){
    return Album(
      realtimeArvl: json['realtimeArrivalList'],
      // rowNum: json['rowNum'],
      // subwayId: json['subwayId'],
      // trainLineNm: json['trainLineNm'],
      // subwayHeading: json['subwayHeading'],
      // arvlMsg2: json['realtimeArrivalList']
    );
  }
}


void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  MyApp({Key key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}
class _MyAppState extends State<MyApp>{
  Future<Album> futureAlbum;
  @override
  void initState(){
      super.initState();
      futureAlbum = fetchAlbum();
  }

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title:'fetch Data Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      )
        ,
      home:Scaffold(
        appBar: AppBar(
        title:Text('Fetch Data Example'),
        ),
        body:Center(
          child: FutureBuilder<Album>(
            future: futureAlbum,
            builder:(context,snapshot){
              String answer = "";
              if(snapshot.hasData){
                answer += "rowNum : ";
                answer += snapshot.data.realtimeArvl[3]['rowNum'].toString();
                answer += "\nsubwayId : ";
                answer += snapshot.data.realtimeArvl[3]['subwayId'].toString();
                answer += "\ntrainLineNm : ";
                answer += snapshot.data.realtimeArvl[3]['trainLineNm'].toString();
                answer += "\nsubwayHeading : ";
                answer += snapshot.data.realtimeArvl[3]['subwayHeading'];
                answer += "\narvlMsg2 : ";
                answer += snapshot.data.realtimeArvl[3]['arvlMsg2'];
                return Text(answer);
            }else if(snapshot.hasError){
                return Text("${snapshot.error}");
            }
              return CircularProgressIndicator();
            },
          ),
        ),
      ),
    );
    }
}
  // This widget is the root of your application.