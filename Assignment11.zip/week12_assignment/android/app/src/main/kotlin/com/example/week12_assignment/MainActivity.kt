package com.example.week12_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
