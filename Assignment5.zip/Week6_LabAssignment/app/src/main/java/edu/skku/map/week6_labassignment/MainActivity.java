package edu.skku.map.week6_labassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textView = (TextView)findViewById(R.id.textView);
        final Context context= this;

        @SuppressLint("StaticFieldLeak") AsyncTask<Integer, Double, String> asyncTask = new AsyncTask<Integer, Double, String>() {
            @Override
            protected String doInBackground(Integer... integers) {
                double total = 0;
                double inCircle = 0;
                for(int i =0;i<integers[0];i++) {
                    double x = Math.random();
                    double y = Math.random();
                    if (Math.pow(x,2) + Math.pow(y,2) <= 1){
                        total += 1;
                        inCircle += 1;
                    }
                    else{
                        total += 1;
                    }
                    try{
                        Thread.sleep(100);
                        double ratio = inCircle/total;
                        double approximatePI = 4 * ratio;
                        publishProgress(approximatePI);
                        if (Math.abs(approximatePI-Math.PI) < 0.000001){
                            return null;
                        }
                    }catch(InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                return null;
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
            }

            @Override
            protected void onProgressUpdate(Double... values) {
                super.onProgressUpdate(values);
                textView.setText(Double.toString(values[0]));
            }

        };
        asyncTask.execute(100);
    }
}