package edu.skku.MAP.myFirstSWPLab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int i_img = 1;
    int i_txt = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView text = (TextView)findViewById(R.id.textView);

        Button btn1 = (Button)findViewById(R.id.button_top);
        btn1.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                i_txt = 1 - i_txt;
                if (i_txt==1){
                    text.setText("Park Soohun");
                }
                if(i_txt==0){
                    text.setText("2016314364");
                }
            }
        });

        Button btn2 = (Button)findViewById(R.id.button_image);
        final ImageView img1 = (ImageView)findViewById(R.id.imageView);
        btn2.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                if(i_img==0){
                    img1.setImageResource(R.drawable.chicken);
                    i_img++;
                }
                else if(i_img==1){
                    img1.setImageResource(R.drawable.pizza);
                    i_img++;
                }
                else if(i_img==2){
                    img1.setImageResource(R.drawable.hamburger);
                    i_img -= 2;
                }

            }
        });
    }
}