package edu.skku.map.pa22016314364parksoohun;

import java.util.HashMap;
import java.util.List;

public class ImageLink {
    private List<HashMap<String, String>> items;
    public List<HashMap<String,String>> getItems() {
        return items;
    }
}
