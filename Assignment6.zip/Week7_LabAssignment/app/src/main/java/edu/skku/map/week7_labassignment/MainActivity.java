package edu.skku.map.week7_labassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText title = (EditText)findViewById(R.id.title);
        TextView content = (TextView)findViewById(R.id.content);
        Button search = (Button)findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OkHttpClient client = new OkHttpClient();
                DataModel data = new DataModel();
                Gson gson = new Gson();

                HttpUrl.Builder urlBuilder = HttpUrl.parse("http://www.omdbapi.com/?i=tt3896198").newBuilder();
                urlBuilder.addQueryParameter("t", title.getText().toString());
                urlBuilder.addQueryParameter("apikey", "34dc9f84");

                String url = urlBuilder.build().toString();

                Request req = new Request.Builder().url(url)
                        .build();
                client.newCall(req).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        final String myresponse = response.body().string();
                        Gson gson = new GsonBuilder().create();
                        DataModel data = gson.fromJson(myresponse, DataModel.class);
                        List<String> contentList = new ArrayList<String>();
                        List<String> category = new ArrayList<String>();
                        contentList.add(data.getTitle());
                        contentList.add(data.getYear());
                        contentList.add(data.getReleased());
                        contentList.add(data.getRuntime());
                        contentList.add(data.getDirector());
                        contentList.add(data.getGenre());
                        contentList.add(data.getImdbRating());
                        contentList.add(data.getMetascore());
                        category.add("Title : ");
                        category.add("Year : ");
                        category.add("Released Date : ");
                        category.add("Runtime : ");
                        category.add("Director : ");
                        category.add("Genre : ");
                        category.add("IMDB Rates : ");
                        category.add("Metascore : ");

                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String listString = new String();
                                for(int i=0;i<8;i++){
                                    listString += category.get(i);
                                    listString += contentList.get(i) + '\n' ;
                                }
                                content.setText(listString);
                            }
                        });
                    }
                });
            }
        });
    }
}