package edu.skku.map.week7_labassignment;

public class DataModel {
    private String Title;
    private String Year;
    private String Released;
    private String Runtime;
    private String Director;
    private String Genre;
    private String imdbRating;
    private String Metascore;

    public String getTitle() {
        return Title;
    }

    public String getYear() {
        return Year;
    }

    public String getReleased() {
        return Released;
    }

    public String getRuntime() {
        return Runtime;
    }

    public String getDirector() {
        return Director;
    }

    public String getGenre() {
        return Genre;
    }

    public String getImdbRating() {
        return imdbRating;
    }

    public String getMetascore() {
        return Metascore;
    }
}
